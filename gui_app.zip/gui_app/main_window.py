from PyQt5.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, 
    QTextEdit, QLineEdit, QPushButton, QLabel, 
    QProgressBar, QSplitter
)
from PyQt5.QtCore import Qt
from interfaces import (
    AI_API, BluetoothAPI, STM32API, CameraAPI
)

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("🌽 农业履带小车终端系统 - 玉米剪切及施肥")
        self.resize(1000, 700)
        
        # 接口实例化
        self.ai_api = AI_API()
        self.bt_api = BluetoothAPI()
        self.stm32_api = STM32API()
        self.cam_api = CameraAPI()
        
        self.init_ui()
    
    def init_ui(self):
        central_widget = QWidget()
        main_layout = QHBoxLayout()
        splitter = QSplitter(Qt.Horizontal)

        # -------------------- 左侧：主视界与状态 --------------------
        left_panel = QWidget()
        left_layout = QVBoxLayout(left_panel)
        
        # 1. 摄像头监控区 (香橙派预留)
        cam_label = QLabel("📷 香橙派画面串流 (预留位)")
        cam_label.setStyleSheet("background-color: #E8F5E9; border: 2px dashed #4CAF50; font-size: 24px;")
        cam_label.setAlignment(Qt.AlignCenter)
        cam_label.setMinimumSize(500, 400)
        left_layout.addWidget(cam_label)

        # 2. 状态面板 (STM32 & 蓝牙)
        status_layout = QVBoxLayout()
        status_title = QLabel("⚙️ 设备与传感状态 (STM32 & 蓝牙通信)")
        status_title.setStyleSheet("font-weight: bold; color: #2E7D32;")
        status_layout.addWidget(status_title)

        # - STM32 状态
        batt_layout = QHBoxLayout()
        batt_label = QLabel("🔋 电池可用电量:")
        self.batt_bar = QProgressBar()
        self.batt_bar.setValue(self.stm32_api.get_battery_level())
        batt_layout.addWidget(batt_label)
        batt_layout.addWidget(self.batt_bar)
        
        zinc_layout = QHBoxLayout()
        zinc_label = QLabel("🧴 锌肥余量状况:")
        self.zinc_bar = QProgressBar()
        self.zinc_bar.setValue(self.stm32_api.get_zinc_level())
        self.zinc_bar.setStyleSheet("QProgressBar::chunk {background-color: #FFC107;}") # 黄色锌肥
        zinc_layout.addWidget(zinc_label)
        zinc_layout.addWidget(self.zinc_bar)

        # - 行为控制日志
        self.log_box = QTextEdit()
        self.log_box.setReadOnly(True)
        self.log_box.setStyleSheet("background-color: #333; color: #00FF00; font-family: monospace;")
        self.log_box.append(">>> 系统初始化完毕。等待蓝牙应用接入...")
        self.log_box.append(">>> STM32 407VGT6 连接正常。")
        self.log_box.setFixedHeight(120)

        status_layout.addLayout(batt_layout)
        status_layout.addLayout(zinc_layout)
        status_layout.addWidget(self.log_box)
        left_layout.addLayout(status_layout)
        
        # -------------------- 右侧：AI 大模型聊天 --------------------
        right_panel = QWidget()
        right_layout = QVBoxLayout(right_panel)
        
        # AI 对话框 (置顶聊天区域)
        ai_title = QLabel("🤖 农智 AI 助手 (大模型专家)")
        ai_title.setStyleSheet("font-weight: bold; color: #1976D2;")
        right_layout.addWidget(ai_title)

        self.chat_display = QTextEdit()
        self.chat_display.setReadOnly(True)
        self.chat_display.setStyleSheet("background-color: #FFFFFF;")
        self.chat_display.append("[AI助手] 您好，专家系统已就绪，可随时分析玉米叶片剪切策略或锌肥配置方案。")

        # 消息输入
        input_layout = QHBoxLayout()
        self.chat_input = QLineEdit()
        self.chat_input.setPlaceholderText("请输入您的问题...")
        self.send_btn = QPushButton("发送(Enter)")

        # 事件绑定
        self.send_btn.clicked.connect(self.send_to_ai)
        self.chat_input.returnPressed.connect(self.send_to_ai)

        input_layout.addWidget(self.chat_input)
        input_layout.addWidget(self.send_btn)

        right_layout.addWidget(self.chat_display)
        right_layout.addLayout(input_layout)

        # ----------- 装配面板 -------------
        splitter.addWidget(left_panel)
        splitter.addWidget(right_panel)
        splitter.setSizes([600, 350]) # 左6右4比例

        main_layout.addWidget(splitter)
        central_widget.setLayout(main_layout)
        self.setCentralWidget(central_widget)

    def send_to_ai(self):
        user_msg = self.chat_input.text()
        if not user_msg: return

        # 显示自己发送的
        self.chat_display.append(f"<b style='color:green;'>[控制端]:</b> {user_msg}")
        self.chat_input.clear()
        
        # 调用 AI API (异步或多线程以防卡死界面，这里做同步模拟)
        reply = self.ai_api.chat_with_model(user_msg)
        self.chat_display.append(f"<b style='color:blue;'>[AI助手]:</b> {reply}")

